import java.io.File;
import java.io.IOException;

public class main {

    public static void main(String[] args) {

        File saveDir = new File("Save");
        File save = new File("Save/save.txt");

        if (!saveDir.exists())
            saveDir.mkdirs();

        if (!save.exists()) {
            try {
                save.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Home home = new Home();

    }
}