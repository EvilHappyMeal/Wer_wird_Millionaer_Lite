import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Home extends JFrame implements ActionListener {

    //Files
    File save = new File("Save/save.txt");
    ImageIcon close = new ImageIcon("Save/cross.png");


    //Integer
    int life = 100;
    int scoreInt = 0;


    //Boolean
    boolean a = true;
    boolean rigtWrong;


    //String
    String questionString;
    String answeraString;
    String answerbString;
    String answercString;
    String answerdString;


    //Array
    boolean[] answers = {false, false, false, false};                 //a,b,c,d
    boolean [] previousQuestions = {false, false, false, false, false, false, false, false, false, false, };
    ArrayList<String> scoreSaveList = new ArrayList<>();
    ArrayList<Integer> saveList = new ArrayList<>();
    ArrayList<String> scoreLoadedList = new ArrayList<>();


    //Buttons
    JButton startGame = new JButton();              //Start Game
    JButton options = new JButton();                //Options
    JButton exit = new JButton();                   //Exit Game
    JButton score = new JButton();                  //Highscore
    JButton exitYes = new JButton();                //ExitPopup Yes
    JButton exitNo = new JButton();                 //ExitPopup NO
    JButton answera = new JButton();                //Answer A
    JButton answerb = new JButton();                //Answer B
    JButton answerc = new JButton();                //Answer C
    JButton answerd = new JButton();                //Answer D
    JButton mainmenu = new JButton();               //Back to Main Menu
    JButton nextQuestion = new JButton();           //next Question
    JButton mainmenuscore = new JButton();          //Back to Main Menu from Score Panel
    JButton leaveGame = new JButton();              //Back to Main Menu from ingame
    JButton leaveOptions = new JButton();           //Back to Main Menu from Options


    //Lists
    JList scoreList = new JList(scoreLoadedList.toArray(new String[scoreLoadedList.size()]));


    //Panels
    JPanel home = new JPanel();                     //homePanel
    JPanel exitGame = new JPanel();                 //Want to exit the game?
    JPanel exitPanel = new JPanel();                //Background ExitGame
    JPanel runGame = new JPanel();                  //ingame Overlay
    JPanel gameOverPanel = new JPanel();            //Game Over
    JPanel nextQuestionPanel = new JPanel();        //next Question
    JPanel scorePanel = new JPanel();               //Highscore
    JPanel optionsPanel = new JPanel();             //Options


    //Labels
    JLabel exitGameLabel = new JLabel();            //Exit the Game?
    JLabel question = new JLabel();                 //Question in Game
    JLabel lifeScoreLabel = new JLabel();           //Life & Score ingame
    JLabel gameOverLabel = new JLabel();            //Game is over
    JLabel lifeScoreLabelGameover = new JLabel();   //Life & Score GameoverPanel
    JLabel rightWrongLabel = new JLabel();          //right or wrong


    //Font
    Font myFont = new Font("Arial", Font.BOLD, 20);

    //Color


    //Border
    Border border = BorderFactory.createLineBorder(Color.RED, 2);


    Home() {

        //Lists

        //Score List
        scoreList.setVisible(true);
        scoreList.setFont(myFont);
        scoreList.setBorder(border);
        scoreList.setBounds(700, 50, 300, 600);


        //Buttons

        //Start Game
        startGame.setVisible(true);
        startGame.setBounds(50, 50, 250, 50);
        startGame.setFocusable(false);
        startGame.setFont(myFont);
        startGame.setText("Spiel starten");
        startGame.setBorder(border);
        startGame.addActionListener(this);

        //Highscore
        score.setVisible(true);
        score.setBounds(50, 150, 250, 50);
        score.setFocusable(false);
        score.setFont(myFont);
        score.setText("Highscore");
        score.setBorder(border);
        score.addActionListener(this);

        //Options
        options.setVisible(true);
        options.setBounds(50, 250, 250, 50);
        options.setFont(myFont);
        options.setFocusable(false);
        options.setText("Optionen");
        options.setBorder(border);
        options.addActionListener(this);

        //ExitGame
        exit.setVisible(true);
        exit.setBounds(50, 350, 250, 50);
        exit.setBorder(border);
        exit.setFont(myFont);
        exit.setFocusable(false);
        exit.setText("Spiel verlassen");
        exit.addActionListener(this);

        //ExitYes
        exitYes.setVisible(true);
        exitYes.setBorder(border);
        exitYes.setFont(myFont);
        exitYes.setFocusable(false);
        exitYes.addActionListener(this);
        exitYes.setText("Ja");
        exitYes.setBounds(300, 200, 100, 50);

        //ExitNo
        exitNo.setVisible(true);
        exitNo.setBorder(border);
        exitNo.setFont(myFont);
        exitNo.setFocusable(false);
        exitNo.addActionListener(this);
        exitNo.setText("Nein");
        exitNo.setBounds(100, 200, 100, 50);

        //Answer A
        answera.setVisible(true);
        answera.setFocusable(false);
        answera.setBorder(border);
        answera.setFont(myFont);
        answera.setBounds(100, 428, 530, 100);
        answera.addActionListener(this);
        answera.setBackground(Color.LIGHT_GRAY);
        answera.setText(answeraString);

        //Answer B
        answerb.setVisible(true);
        answerb.setFocusable(false);
        answerb.setBorder(border);
        answerb.setFont(myFont);
        answerb.setBounds(650, 428, 530, 100);
        answerb.addActionListener(this);
        answerb.setBackground(Color.LIGHT_GRAY);
        answerb.setText(answerbString);

        //Answer C
        answerc.setVisible(true);
        answerc.setFocusable(false);
        answerc.setBorder(border);
        answerc.setFont(myFont);
        answerc.setBounds(100, 548, 530, 100);
        answerc.addActionListener(this);
        answerc.setBackground(Color.LIGHT_GRAY);
        answerc.setText(answercString);

        //Answer D
        answerd.setVisible(true);
        answerd.setFocusable(false);
        answerd.setBorder(border);
        answerd.setFont(myFont);
        answerd.setBounds(650, 548, 530, 100);
        answerd.addActionListener(this);
        answerd.setBackground(Color.LIGHT_GRAY);
        answerd.setText(answerdString);

        //mainMenu
        mainmenu.setVisible(true);
        mainmenu.setBounds(50, 350, 250, 50);
        mainmenu.setBorder(border);
        mainmenu.setFont(myFont);
        mainmenu.setFocusable(false);
        mainmenu.setText("Hauptmenü");
        mainmenu.addActionListener(this);

        //next Question
        nextQuestion.setVisible(false);
        nextQuestion.setBounds(515, 500, 250, 50);
        nextQuestion.setBorder(border);
        nextQuestion.setFont(myFont);
        nextQuestion.setFocusable(false);
        nextQuestion.setText("Weiter");
        nextQuestion.addActionListener(this);

        //Main Menu Scorepanel
        mainmenuscore.setVisible(true);
        mainmenuscore.setBounds(100, 500, 250, 50);
        mainmenuscore.setBorder(border);
        mainmenuscore.setFont(myFont);
        mainmenuscore.setFocusable(false);
        mainmenuscore.setText("Hauptmenü");
        mainmenuscore.addActionListener(this);

        //Leave Game
        leaveGame.setVisible(true);
        leaveGame.setBounds(1180, 50, 50, 50);
        leaveGame.setBorder(border);
        leaveGame.setFont(myFont);
        leaveGame.setFocusable(false);
        leaveGame.setIcon(close);
        leaveGame.addActionListener(this);

        //Leave Options
        leaveOptions.setVisible(true);
        leaveOptions.setBounds(100, 500, 250, 50);
        leaveOptions.setBorder(border);
        leaveOptions.setFont(myFont);
        leaveOptions.setFocusable(false);
        leaveOptions.setText("Hauptmenü");
        leaveOptions.addActionListener(this);


        //Labels

        //Game Over
        gameOverLabel.setFont(new Font("Arial", Font.BOLD, 40));
        gameOverLabel.setText("Game Over");
        gameOverLabel.setVisible(true);
        gameOverLabel.setBorder(border);
        gameOverLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gameOverLabel.setBounds(500, 500, 100, 80);

        //Life & Score ingame
        lifeScoreLabel.setFont(myFont);
        lifeScoreLabel.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);
        lifeScoreLabel.setVisible(true);
        lifeScoreLabel.setBorder(border);
        lifeScoreLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lifeScoreLabel.setBounds(50, 50, 400, 50);

        //Life & Score GameOverPanel
        lifeScoreLabelGameover.setFont(myFont);
        lifeScoreLabelGameover.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);
        lifeScoreLabelGameover.setVisible(true);
        lifeScoreLabelGameover.setBorder(border);
        lifeScoreLabelGameover.setHorizontalAlignment(SwingConstants.CENTER);
        lifeScoreLabelGameover.setBounds(50, 50, 400, 50);

        //ExitLabel
        exitGameLabel.setFont(myFont);
        exitGameLabel.setText("Möchtest du das Spiel verlassen?");
        exitGameLabel.setVisible(true);
        exitGameLabel.setBorder(border);
        exitGameLabel.setHorizontalAlignment(SwingConstants.CENTER);
        exitGameLabel.setBounds(75, 50, 340, 50);

        //Question in Game
        question.setFont(myFont);
        question.setVisible(true);
        question.setBorder(border);
        question.setHorizontalAlignment(SwingConstants.CENTER);
        question.setBounds(100, 208, 1080, 200);
        question.setOpaque(true);
        question.setBackground(Color.LIGHT_GRAY);
        question.setText(questionString);

        //right or wrong Label
        rightWrongLabel.setFont(myFont);
        rightWrongLabel.setVisible(true);
        rightWrongLabel.setBorder(border);
        rightWrongLabel.setHorizontalAlignment(SwingConstants.CENTER);
        rightWrongLabel.setBounds(100, 208, 1080, 200);
        rightWrongLabel.setOpaque(true);
        rightWrongLabel.setBackground(new Color(50, 50, 50, 100));
        rightWrongLabel.setText(questionString);


        //Panel

        //homePanel
        home.setVisible(true);
        home.setFont(myFont);
        home.setBounds(0, 0, 1281, 698);
        home.setOpaque(true);
        home.setLayout(null);
        home.setBorder(border);

        //HighscorePanel
        scorePanel.setVisible(false);
        scorePanel.setFont(myFont);
        scorePanel.setBounds(0, 0, 1281, 698);
        scorePanel.setOpaque(true);
        scorePanel.setLayout(null);
        scorePanel.setBorder(border);

        //ExitGame
        exitGame.setVisible(true);
        exitGame.setFont(myFont);
        exitGame.setBounds(350, 200, 500, 300);
        exitGame.setOpaque(true);
        exitGame.setLayout(null);
        exitGame.setBorder(border);

        //Background ExitGame
        exitPanel.setVisible(false);
        exitPanel.setLayout(null);
        exitPanel.setBounds(0, 0, 1281, 698);
        exitPanel.setBackground(new Color(10, 10, 10, 100));

        //runGame
        runGame.setVisible(false);
        runGame.setFont(myFont);
        runGame.setBounds(0, 0, 1281, 698);
        runGame.setOpaque(true);
        runGame.setLayout(null);
        runGame.setBorder(border);

        //next Question
        nextQuestionPanel.setVisible(false);
        nextQuestionPanel.setFont(myFont);
        nextQuestionPanel.setBounds(0, 0, 1281, 698);
        nextQuestionPanel.setOpaque(true);
        nextQuestionPanel.setLayout(null);
        nextQuestionPanel.setBorder(border);
        nextQuestionPanel.setBackground(Color.GREEN);

        //Game Over
        gameOverPanel.setVisible(false);
        gameOverPanel.setFont(myFont);
        gameOverPanel.setBounds(0, 0, 1281, 698);
        gameOverPanel.setOpaque(true);
        gameOverPanel.setLayout(null);
        gameOverPanel.setBorder(border);

        //Options
        optionsPanel.setVisible(false);
        optionsPanel.setFont(myFont);
        optionsPanel.setBounds(0, 0, 1281, 698);
        optionsPanel.setOpaque(true);
        optionsPanel.setLayout(null);
        optionsPanel.setBorder(border);


        //Frame
        this.setExtendedState(MAXIMIZED_BOTH);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setTitle("Wer wird Millionär Lite");
        this.setResizable(false);

        //add
        this.add(home);
        this.add(runGame);
        this.add(gameOverPanel);
        this.add(nextQuestionPanel);
        this.add(scorePanel);
        this.add(optionsPanel);

        scorePanel.add(scoreList);
        scorePanel.add(mainmenuscore);

        runGame.add(answera);
        runGame.add(answerb);
        runGame.add(answerc);
        runGame.add(answerd);
        runGame.add(question);
        runGame.add(lifeScoreLabel);
        runGame.add(leaveGame);

        nextQuestionPanel.add(nextQuestion);
        nextQuestionPanel.add(rightWrongLabel);

        gameOverPanel.add(lifeScoreLabelGameover);
        gameOverPanel.add(mainmenu);

        home.add(exitPanel);
        home.add(startGame);
        home.add(options);
        home.add(score);
        home.add(exit);

        exitPanel.add(exitGame);
        exitGame.add(exitNo);
        exitGame.add(exitYes);
        exitGame.add(exitGameLabel);

        optionsPanel.add(leaveOptions);


    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == options){

            optionsPanel.setVisible(true);

            home.setVisible(false);

        }

        if (e.getSource() == nextQuestion) {

            runGame.setVisible(true);
            nextQuestionPanel.setVisible(false);
            nextQuestion.setVisible(false);

            runGame();

        }

        if (e.getSource() == exit) {

            a = false;
            exitPanel.setVisible(true);

        }

        if (e.getSource() == exitYes) {

            dispose();

        }

        if (e.getSource() == exitNo) {

            a = true;
            exitPanel.setVisible(false);

        }

        if (e.getSource() == startGame) {

            answera.setBackground(Color.lightGray);
            answerb.setBackground(Color.lightGray);
            answerc.setBackground(Color.lightGray);
            answerd.setBackground(Color.lightGray);

            life = 100;
            scoreInt = 0;

            lifeScoreLabel.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);

            answera.updateUI();
            answerb.updateUI();
            answerc.updateUI();
            answerd.updateUI();
            lifeScoreLabel.updateUI();

            home.setVisible(false);
            runGame.setVisible(true);

            runGame();

        }

        if (e.getSource() == mainmenu || e.getSource() == leaveOptions || e.getSource() == mainmenuscore || e.getSource() == leaveGame) {

            gameOverPanel.setVisible(false);
            scorePanel.setVisible(false);
            runGame.setVisible(false);
            optionsPanel.setVisible(false);


            home.setVisible(true);

        }

        if (e.getSource() == score) {

            loadSave();

            Collections.sort(scoreSaveList);
            scoreList.setListData(scoreSaveList.toArray(new String[scoreSaveList.size()]));
            scoreList.updateUI();

            scoreSaveList.clear();

            home.setVisible(false);
            scorePanel.setVisible(true);

        }

        if (e.getSource() == answera) {

            if (!answers[0]) {
                answera.setBackground(Color.RED);
                life = life - 25;
                rigtWrong = false;
            } else {
                answera.setBackground(Color.GREEN);
                if (life <= 95)
                    life = life + 5;
                scoreInt = scoreInt + 100;
                rigtWrong = true;
            }

            if (life <= 0) {
                gameOver();
            }

            lifeScoreLabel.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);
            lifeScoreLabelGameover.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);
            answera.updateUI();
            lifeScoreLabel.updateUI();
            lifeScoreLabelGameover.updateUI();

            nextQuestion();

        }
        if (e.getSource() == answerb) {

            if (!answers[1]) {
                answerb.setBackground(Color.RED);
                life = life - 25;
                rigtWrong = false;
            } else {
                answerb.setBackground(Color.GREEN);
                if (life <= 95)
                    life = life + 5;
                scoreInt = scoreInt + 100;
                rigtWrong = true;

            }

            if (life <= 0) {
                gameOver();
            }

            lifeScoreLabel.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);
            lifeScoreLabelGameover.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);
            answerb.updateUI();
            lifeScoreLabel.updateUI();
            lifeScoreLabelGameover.updateUI();

            nextQuestion();

        }
        if (e.getSource() == answerc) {

            if (!answers[2]) {
                answerc.setBackground(Color.RED);
                life = life - 25;
                rigtWrong = false;
            } else {
                answerc.setBackground(Color.GREEN);
                if (life <= 95)
                    life = life + 5;
                scoreInt = scoreInt + 100;
                rigtWrong = true;
            }

            if (life <= 0) {
                gameOver();
            }

            lifeScoreLabel.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);
            lifeScoreLabelGameover.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);
            answerc.updateUI();
            lifeScoreLabel.updateUI();
            lifeScoreLabelGameover.updateUI();

            nextQuestion();

        }
        if (e.getSource() == answerd) {

            if (!answers[3]) {
                answerd.setBackground(Color.RED);
                life = life - 25;
                rigtWrong = false;
            } else {
                answerd.setBackground(Color.GREEN);
                if (life <= 95)
                    life = life + 5;
                scoreInt = scoreInt + 100;
                rigtWrong = true;
            }

            if (life <= 0) {
                gameOver();
            }

            lifeScoreLabel.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);
            lifeScoreLabelGameover.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);
            answerd.updateUI();
            lifeScoreLabel.updateUI();
            lifeScoreLabelGameover.updateUI();

            nextQuestion();

        }


    }

    private void nextQuestion() {

        String content;

        if (rigtWrong) {

            rightWrongLabel.setText("Richtig!!");
            nextQuestionPanel.setBackground(Color.GREEN);

        } else {

            if (answers[0])
                content = answeraString;
            else if (answers[1])
                content = answerbString;
            else if (answers[2])
                content = answercString;
            else
                content = answerdString;

            rightWrongLabel.setText("<html><body>Falsch!!<br>Richtig wäre:<br>" + content + "</body></html>");
            nextQuestionPanel.setBackground(Color.RED);

        }

        rightWrongLabel.updateUI();
        nextQuestionPanel.updateUI();

        runGame.setVisible(false);
        nextQuestionPanel.setVisible(true);
        nextQuestion.setVisible(true);

        answera.setBackground(Color.lightGray);
        answerb.setBackground(Color.lightGray);
        answerc.setBackground(Color.lightGray);
        answerd.setBackground(Color.lightGray);

        answera.updateUI();
        answerb.updateUI();
        answerc.updateUI();
        answerd.updateUI();

    }

    private void gameOver() {

        Save();

        life = 0;
        lifeScoreLabelGameover.setText("Leben: " + life + "     " + "Punkte: " + scoreInt);

        runGame.setVisible(false);
        nextQuestion.setVisible(false);
        nextQuestionPanel.setVisible(false);

        gameOverPanel.setVisible(true);

    }

    private void loadSave() {

        try {
            Scanner sc = new Scanner(save);
            while (sc.hasNextInt()) {
                scoreSaveList.add(String.valueOf(sc.nextInt()));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    private void Save() {

        try {
            Scanner sc = new Scanner(save);
            while (sc.hasNext()) {
                saveList.add(Integer.valueOf(sc.nextLine()));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        saveList.add(scoreInt);

        BufferedWriter writer;

        String content;

        try {
            writer = new BufferedWriter(new FileWriter(save));
            for (int i = 0; i <= saveList.size() - 1; i++) {
                content = String.valueOf(saveList.get(i));
                writer.write(content);
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void runGame() {

        int randomInt = (int) (Math.random() * 10);
        for (int i = 0; i < 4; i++) {

            answers[i] = false;

        }

        if (previousQuestions [0] && previousQuestions [1] &&
                previousQuestions [2] && previousQuestions [3] &&
                previousQuestions [4] && previousQuestions [5] &&
                previousQuestions [6] && previousQuestions [7] &&
                previousQuestions [8] && previousQuestions [9]){
            for (int i = 0; i < 10; i++) {
                previousQuestions [i] = false;
            }
        }

        while (previousQuestions [randomInt])
            randomInt = (int) (Math.random() * 10);

        switch (randomInt) {

            case 0 -> {
                questionString = "Was ist „der Frau“ und „der Tochter“?";
                answeraString = "A: " + "Höflichkeitsform";
                answerbString = "B: " + "Konjunktiv";
                answercString = "C: " + "Genitiv";
                answerdString = "D: " + "Transsexualität";

                answers[2] = true;

                answerd.setText(answerdString);
                answerc.setText(answercString);
                answerb.setText(answerbString);
                answera.setText(answeraString);
                question.setText(questionString);

                answera.updateUI();
                answerb.updateUI();
                answerc.updateUI();
                answerd.updateUI();
                question.updateUI();
                runGame.updateUI();

            }

            case 1 -> {
                questionString = "Wobei handelt es sich um ein beliebtes Getränk an kalten Tagen?";
                answeraString = "A: " + "call me strawberry";
                answerbString = "B: " + "heiße Zitrone";
                answercString = "C: " + "nennt mich Kirsche";
                answerdString = "D: " + "bin die Banane";

                answers[1] = true;

                answerd.setText(answerdString);
                answerc.setText(answercString);
                answerb.setText(answerbString);
                answera.setText(answeraString);
                question.setText(questionString);

                answera.updateUI();
                answerb.updateUI();
                answerc.updateUI();
                answerd.updateUI();
                question.updateUI();
                runGame.updateUI();

            }

            case 2 -> {
                questionString = "Scotty, der Ingenieur des Raumschiffs Enterprise, war bei den „Ausflügen“ meist nicht dabei, weil er ...?";
                answeraString = "A: " + "angestellte";
                answerbString = "B: " + "beamte";
                answercString = "C: " + "selbstständige";
                answerdString = "D: " + "vorgesetzte";

                answers[1] = true;

                answerd.setText(answerdString);
                answerc.setText(answercString);
                answerb.setText(answerbString);
                answera.setText(answeraString);
                question.setText(questionString);

                answera.updateUI();
                answerb.updateUI();
                answerc.updateUI();
                answerd.updateUI();
                question.updateUI();
                runGame.updateUI();

            }

            case 3 -> {
                questionString = "Welchen Warnhinweis sieht man häufig im Alltag?";
                answeraString = "A: " + "Böll findet nicht statt!";
                answerbString = "B: " + "Grass entfällt!";
                answercString = "C: " + "Brecht abgesagt!";
                answerdString = "D: " + "Frisch gestrichen!";

                answers[3] = true;

                answerd.setText(answerdString);
                answerc.setText(answercString);
                answerb.setText(answerbString);
                answera.setText(answeraString);
                question.setText(questionString);

                answera.updateUI();
                answerb.updateUI();
                answerc.updateUI();
                answerd.updateUI();
                question.updateUI();
                runGame.updateUI();

            }

            case 4 -> {
                questionString = "Wofür gibt es einen Oscar?";
                answeraString = "A: " + "Toller Chirurg";
                answerbString = "B: " + "Exquisites Skalpell";
                answercString = "C: " + "Bester Schnitt";
                answerdString = "D: " + "Fabelhafte OP";

                answers[2] = true;

                answerd.setText(answerdString);
                answerc.setText(answercString);
                answerb.setText(answerbString);
                answera.setText(answeraString);
                question.setText(questionString);

                answera.updateUI();
                answerb.updateUI();
                answerc.updateUI();
                answerd.updateUI();
                question.updateUI();
                runGame.updateUI();

            }

            case 5 -> {
                questionString = "Wenn man eins von zwei Löchern im Reifen flickt, dann wird er ...?";
                answeraString = "A: " + "bildhauer";
                answerbString = "B: " + "maler";
                answercString = "C: " + "dichter";
                answerdString = "D: " + "sänger";

                answers[2] = true;

                answerd.setText(answerdString);
                answerc.setText(answercString);
                answerb.setText(answerbString);
                answera.setText(answeraString);
                question.setText(questionString);

                answera.updateUI();
                answerb.updateUI();
                answerc.updateUI();
                answerd.updateUI();
                question.updateUI();
                runGame.updateUI();

            }

            case 6 -> {
                questionString = "Die Dinosaurier lebten ...?";
                answeraString = "A: " + "in der Kreide";
                answerbString = "B: " + "knietief im Dispo";
                answercString = "C: " + "auf Pump";
                answerdString = "D: " + "mit Schulden";

                answers[0] = true;

                answerd.setText(answerdString);
                answerc.setText(answercString);
                answerb.setText(answerbString);
                answera.setText(answeraString);
                question.setText(questionString);

                answera.updateUI();
                answerb.updateUI();
                answerc.updateUI();
                answerd.updateUI();
                question.updateUI();
                runGame.updateUI();

            }

            case 7 -> {
                questionString = "1/4 ist ein ...?";
                answeraString = "A: " + "Bankraub";
                answerbString = "B: " + "Diebstahl";
                answercString = "C: " + "ScheckBetrug";
                answerdString = "D: " + "Bruch";

                answers[3] = true;

                answerd.setText(answerdString);
                answerc.setText(answercString);
                answerb.setText(answerbString);
                answera.setText(answeraString);
                question.setText(questionString);

                answera.updateUI();
                answerb.updateUI();
                answerc.updateUI();
                answerd.updateUI();
                question.updateUI();
                runGame.updateUI();

            }

            case 8 -> {
                questionString = "Was dient nicht zur Verhütung?";
                answeraString = "A: " + "Kondom";
                answerbString = "B: " + "Coitus interruptus";
                answercString = "C: " + "Glücksspirale";
                answerdString = "D: " + "Pille";

                answers[2] = true;

                answerd.setText(answerdString);
                answerc.setText(answercString);
                answerb.setText(answerbString);
                answera.setText(answeraString);
                question.setText(questionString);

                answera.updateUI();
                answerb.updateUI();
                answerc.updateUI();
                answerd.updateUI();
                question.updateUI();
                runGame.updateUI();

            }

            case 9 -> {
                questionString = "Was kommt in Ostasien häufig auf den Tisch?";
                answeraString = "A: " + "Sonicht";
                answerbString = "B: " + "Soschoneher";
                answercString = "C: " + "Soja";
                answerdString = "D: " + "Sovielleicht";

                answers[2] = true;

                answerd.setText(answerdString);
                answerc.setText(answercString);
                answerb.setText(answerbString);
                answera.setText(answeraString);
                question.setText(questionString);

                answera.updateUI();
                answerb.updateUI();
                answerc.updateUI();
                answerd.updateUI();
                question.updateUI();
                runGame.updateUI();

            }
        }

        previousQuestions [randomInt] = true;

    }

}
